// Please don't change the pre-written code
// Import the necessary modules here

export const registerUser = (req, res, next) => {
  // Write your code here
};

export const loginUser = (req, res) => {
  // Write your code here
};
