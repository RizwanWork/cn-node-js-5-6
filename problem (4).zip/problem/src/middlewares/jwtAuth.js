// Please don't change the pre-written code
// Import the necessary modules here

const jwtAuth = (req, res, next) => {
  // Write your code here
};

export default jwtAuth;
